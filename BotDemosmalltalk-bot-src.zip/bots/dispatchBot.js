// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { ActivityHandler } = require('botbuilder');
const { LuisRecognizer, QnAMaker } = require('botbuilder-ai');
const { CosmosDbStorage ,CosmosDbPartitionedStorage} = require("botbuilder-azure");

class DispatchBot extends ActivityHandler {
    constructor() {
        super();

        // If the includeApiResults parameter is set to true, as shown below, the full response
        // from the LUIS api will be made available in the properties  of the RecognizerResult
        const dispatchRecognizer = new LuisRecognizer({
            applicationId: process.env.LuisAppId,
            endpointKey: process.env.LuisAPIKey,
            endpoint: `https://${ process.env.LuisAPIHostName }.api.cognitive.microsoft.com`
        }, {
            includeAllIntents: true,
            includeInstanceData: true
        }, true);

        const qnaMaker = new QnAMaker({
            knowledgeBaseId: "f9779834-837a-43df-a774-2b852967bbfb",
            endpointKey: "46da879a-a333-4d87-b71c-13e957d6f70d",
            host: "https://astarsmalltalk.azurewebsites.net/qnamaker"
        });
        
        //ES07112019
      //  var storage = new CosmosDbPartitionedStorage({
   // cosmosDbEndpoint: process.env.DB_SERVICE_ENDPOINT, 
   // authKey: process.env.AUTH_KEY, 
   // databaseId: process.env.DATABASE_ID,
   // containerId: process.env.CONTAINER
//});

        this.dispatchRecognizer = dispatchRecognizer;
        this.qnaMaker = qnaMaker;

        this.onMessage(async (context, next) => {
            console.log('Processing Message Activity.');
         //  await context.sendActivity(`You said`+context.activity.text);
            // First, we use the dispatch model to determine which cognitive service (LUIS or QnA) to use.
            const recognizerResult = await dispatchRecognizer.recognize(context);

            // Top intent tell us which cognitive service to use.
            const intent = LuisRecognizer.topIntent(recognizerResult);

            // Next, we call the dispatcher with the top intent.
            await this.dispatchToTopIntentAsync(context, intent, recognizerResult);

            await next();
        });

        this.onMembersAdded(async (context, next) => {
          /*  const welcomeText = 'What can I help?';
            const membersAdded = context.activity.membersAdded;

            for (const member of membersAdded) {
                if (member.id !== context.activity.recipient.id) {
                    await context.sendActivity(`Welcome to DataBot`);
                }
            }*/
           const membersAdded = context.activity.membersAdded;
            for (let cnt = 0; cnt < membersAdded.length; cnt++) {
                if (membersAdded[cnt].id !== context.activity.recipient.id) {
                    await context.sendActivity('Welcome to the DataWork Agent!\n Ask me a question and I will try to answer it.');
                }
            }


            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });
    }

    async dispatchToTopIntentAsync(context, intent, recognizerResult) {
      //  await context.sendActivity(`You said 2`+context.activity.text);
        console.log(`LUIS Intent`);
        switch (intent) {
       // case 'l_HomeAutomation':
        //    await this.processHomeAutomation(context, recognizerResult.luisResult);
         //   break;
      //  case 'l_Weather':
         //   await this.processWeather(context, recognizerResult.luisResult);
          //  break;
       // case 'DataWorkIntent':
             //await context.sendActivity(`In Contruction!!`);
       // case 'None':
            // await context.sendActivity(`In Contruction!!`);
       case 'None':
            await context.sendActivity(`intent: ${ intent }.`);
             await context.sendActivity(`In Construction!!`);
             
             
            break;
        case 'QnAmaker':
           
            await this.processSampleQnA(context);
            
            
            break;
        default:
            console.log(`Dispatch unrecognized intent: ${ intent }.`);
            await context.sendActivity(`Dispatch unrecognized intent: ${ intent }.`);
           break;
        }
    }

    async processHomeAutomation(context, luisResult) {
        console.log('processHomeAutomation');

        // Retrieve LUIS result for Process Automation.
        const result = luisResult.connectedServiceResult;
        const intent = result.topScoringIntent.intent;

        await context.sendActivity(`HomeAutomation top intent ${ intent }.`);
        await context.sendActivity(`HomeAutomation intents detected:  ${ luisResult.intents.map((intentObj) => intentObj.intent).join('\n\n') }.`);

        if (luisResult.entities.length > 0) {
            await context.sendActivity(`HomeAutomation entities were found in the message: ${ luisResult.entities.map((entityObj) => entityObj.entity).join('\n\n') }.`);
        }
    }

    async processWeather(context, luisResult) {
        console.log('processWeather');

        // Retrieve LUIS results for Weather.
        const result = luisResult.connectedServiceResult;
        const topIntent = result.topScoringIntent.intent;

        await context.sendActivity(`ProcessWeather top intent ${ topIntent }.`);
        await context.sendActivity(`ProcessWeather intents detected:  ${ luisResult.intents.map((intentObj) => intentObj.intent).join('\n\n') }.`);

        if (luisResult.entities.length > 0) {
            await context.sendActivity(`ProcessWeather entities were found in the message: ${ luisResult.entities.map((entityObj) => entityObj.entity).join('\n\n') }.`);
        }
    }

    async processSampleQnA(context) {
          // await context.sendActivity(`You said 3`+context.activity.text);
        console.log('processSampleQnA');
           //timestamp
           //context.activity.channelId;context.activity.timestamp.toLocalString();
        const results = await this.qnaMaker.getAnswers(context);
        
        if (results.length > 0) {
            await context.sendActivity(`${ results[0].answer }`);
            
            let QnAanswers=results[0].answer;
            //ES07112019
          // await logMessageText(storage,context);
           await this.processStorage(context,QnAanswers);
            
        } else {
            await context.sendActivity('Sorry, could not find an answer in the Q and A system.');
        }
    }
    
       async processStorage(context,QnAanswers) {
        console.log('processQnAStorage');
           //await context.sendActivity(`processStorage`);

        let datetime=Date.now();
        let date_ob = new Date(datetime);
        let date = date_ob.getDate();
        let month = date_ob.getMonth() + 1;
        let year = date_ob.getFullYear();
        
        let hours = date_ob.getHours();
        // current minutes
        let minutes = date_ob.getMinutes();
        // current seconds
        let seconds = date_ob.getSeconds();

// prints date & time in YYYY-MM-DD format
//console.log(year + "-" + month + "-" + date+"-"+Math.floor(datetime/1000));
        let dateformat=year + "-" + month + "-" + date+"-"+hours+":"+minutes+":"+seconds;
        
        let questions=context.activity.text;
        let answer=QnAanswers;
        
        var myNoteData={
            name:"QnA data",
            contents: "",dateformat,questions,answer,
            eTags:"*"
        }
                var storage_cosmo = new CosmosDbPartitionedStorage({
    cosmosDbEndpoint: "https://cosmodb2.documents.azure.com:443/", 
    authKey: "RYvAymUKCfvbczmjluwJfOo8UUMPO94e88Eu2RArV3tYXB9WDNDR4mjQx6mfBD1Hm7fJKAWaT2fk6xo5vik0WQ==", 
    databaseId: "ToDoList",
    containerId: "Items"
})
        var changes={}
        changes[dateformat]=myNoteData;
        try{
            await storage_cosmo.write(changes);
            var list=changes[dateformat].contents;
           // await context.sendActivity(`Successful create a note ${list}`);
           console.log(`Successful create a note ${list}`);
            
        }catch(err)
        {
            console.log(`Error: ${err}`);
           // await context.sendActivity(`Error: ${err}`);
        }

    }
    
    
    

}

module.exports.DispatchBot = DispatchBot;